# Dummy LLRPClientFactory implementation
class LLRPClientFactory:
    def __init__(self, ip, on_tag_report):
        self.ip = ip
        self.on_tag_report = on_tag_report
    def connect(self):
        print(f"Connecting to reader at {self.ip}")