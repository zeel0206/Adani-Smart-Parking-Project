const { createClient } = require('@supabase/supabase-js');
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');

const supabase = createClient(
  'https://your-project-url.supabase.co',
  'your-service-role-key' // Use service role token (NOT anon/public)
);

const BLOCK_DURATION_MS = 5 * 60 * 1000;
const blockedTags = new Map(); // { rfid: timestamp }

// --- Utility ---
function isBlocked(rfid) {
  const lastTime = blockedTags.get(rfid);
  if (!lastTime) return false;
  return Date.now() - lastTime < BLOCK_DURATION_MS;
}

// --- Set Up Scanner ---
const port = new SerialPort({ path: 'COM3', baudRate: 9600 });
const parser = port.pipe(new Readline({ delimiter: '\r\n' }));

parser.on('data', async (rfid) => {
  rfid = rfid.trim();
  console.log('📡 RFID Scanned:', rfid);

  if (isBlocked(rfid)) {
    console.log(`⛔ Ignored (duplicate within 5 mins): ${rfid}`);
    return;
  }

  blockedTags.set(rfid, Date.now());

  // Check if active truck with this RFID exists
  const { data: active, error } = await supabase
    .from('truck_entries')
    .select('*')
    .eq('rfid_code', rfid)
    .eq('is_active', true)
    .maybeSingle();

  if (error) {
    console.error('❌ Supabase Error:', error.message);
    return;
  }

  if (!active) {
    // First entry → insert
    const { error: insertErr } = await supabase.from('truck_entries').insert([
      {
        truck_number: 'TRUCK-' + rfid,
        rfid_code: rfid,
        is_active: true,
        created_at: new Date().toISOString(),
      },
    ]);

    if (insertErr) {
      console.error('❌ Insert Error:', insertErr.message);
    } else {
      console.log(`✅ Truck ${rfid} entered.`);
    }

  } else {
    // Truck already inside
    if (active.priority_tag) {
      console.log(`✅ Priority Re-entry for ${rfid} allowed`);
    } else {
      console.log(`❌ Re-entry denied for ${rfid} (no priority tag)`);
    }
  }
});
