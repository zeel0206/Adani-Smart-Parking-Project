// supabase/functions/fastag-entry/index.ts

import { serve } from 'https://deno.land/std/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js'

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_KEY')!
)

// In-memory cache (resets on redeploy)
const recentScans = new Map<string, number>()

serve(async (req) => {
  const { epc } = await req.json()
  const now = Date.now()

  if (!epc) {
    return new Response("Missing EPC", { status: 400 })
  }

  // 🕒 Ignore duplicates for 5 minutes
  if (recentScans.has(epc) && now - recentScans.get(epc)! < 5 * 60 * 1000) {
    return new Response(JSON.stringify({ status: 'ignored', reason: 'duplicate scan' }), { status: 200 })
  }
  recentScans.set(epc, now)

  // 📦 Check if this truck is already inside
  const { data: activeTruck, error: fetchError } = await supabase
    .from('truck_entries')
    .select('*')
    .eq('rfid_code', epc)
    .eq('is_active', true)
    .maybeSingle()

  if (fetchError) {
    return new Response(fetchError.message, { status: 500 })
  }

  if (activeTruck) {
    if (activeTruck.priority_tag) {
      // ✅ Allow re-entry by exiting old entry and creating new one
      const nowISO = new Date().toISOString()

      const { error: updateErr } = await supabase
        .from('truck_entries')
        .update({ exited_at: nowISO, is_active: false })
        .eq('id', activeTruck.id)

      if (updateErr) {
        return new Response(updateErr.message, { status: 500 })
      }

      const { error: reentryErr } = await supabase.from('truck_entries').insert([{
        truck_number: activeTruck.truck_number,
        company_name: activeTruck.company_name,
        purpose: activeTruck.purpose,
        slot: activeTruck.slot,
        truck_type: activeTruck.truck_type,
        is_active: true,
        rfid_code: epc,
        priority_tag: false // Clear priority after re-entry
      }])

      if (reentryErr) {
        return new Response(reentryErr.message, { status: 500 })
      }

      return new Response(JSON.stringify({ status: 'reentry_granted' }), { status: 200 })
    }

    // ❌ Deny access — already inside and no priority
    return new Response(JSON.stringify({ status: 'reentry_denied' }), { status: 200 })
  }

  // 🆕 New truck entry
  const { error: insertErr } = await supabase.from('truck_entries').insert([{
    rfid_code: epc,
    is_active: true,
    created_at: new Date().toISOString()
  }])

  if (insertErr) {
    return new Response(insertErr.message, { status: 500 })
  }

  return new Response(JSON.stringify({ status: 'entry_recorded' }), { status: 200 })
})
