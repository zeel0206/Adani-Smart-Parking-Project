import logging
from sllurp import llrp
from twisted.internet import reactor

logging.basicConfig(level=logging.INFO)

def on_tag_report(reader, tags):
    for tag in tags:
        epc = tag['epc'].decode('utf-8')
        print(f"📦 Tag Read: {epc}")
        handle_tag(epc)

def handle_tag(epc):
    print(f"🔧 Handling EPC: {epc}")
    # Integrate here with your parking system/database if needed

def main():
    READER_IP = '192.168.1.10'  # Only IP, not with :5084

    factory = llrp.LLRPClientFactory(
        READER_IP,
        on_tag_report=on_tag_report,
    )

    def on_connected(client):
        logging.info("✅ Connected to reader. Starting inventory...")
        client.start()  # Sends ROSpec and starts inventory

    factory.on_connected = on_connected

    factory.connect()
    reactor.run()

if __name__ == '__main__':
    main()
