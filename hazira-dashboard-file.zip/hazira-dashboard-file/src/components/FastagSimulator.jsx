import { useState } from 'react';

export default function FastagSimulator() {
  const [truckNumber, setTruckNumber] = useState('');
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleScan = async () => {
    setLoading(true);
    setResponse(null);
    try {
      const res = await fetch('https://bdcxfoekzgyxykqeeojl.supabase.co/functions/v1/fastag-entry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ truck_number: truckNumber }),
      });
      const data = await res.json();
      setResponse(data);
    } catch (error) {
      setResponse({ error: 'Something went wrong' });
    }
    setLoading(false);
  };

  return (
    <div className="p-6 bg-white rounded shadow max-w-xl mx-auto mt-10">
      <h2 className="text-xl font-bold mb-4">FASTag Scan Simulator</h2>

      <input
        type="text"
        placeholder="Enter Truck Number"
        value={truckNumber}
        onChange={(e) => setTruckNumber(e.target.value)}
        className="border px-4 py-2 rounded w-full mb-4"
      />

      <button
        onClick={handleScan}
        disabled={loading || truckNumber === ''}
        className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
      >
        {loading ? 'Scanning...' : 'Simulate FASTag Scan'}
      </button>

      {response && (
        <div className="mt-4 bg-gray-100 p-4 rounded text-sm">
          <strong>Response:</strong>
          <pre>{JSON.stringify(response, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}
