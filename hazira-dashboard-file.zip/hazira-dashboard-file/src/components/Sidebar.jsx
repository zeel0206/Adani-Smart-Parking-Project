import { Link, useLocation, useNavigate } from 'react-router-dom';
import { supabase } from '../supabaseClient';

const navItems = [
  { name: 'Dashboard', path: '/' },
  { name: 'Truck Entry', path: '/register' },
  { name: 'Truck Summary', path: '/summary' },
  { name: 'Rate Module', path: '/rates' },
  { name: 'Reports', path: '/reports' },
];

export default function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/login');
  };

  return (
    <div className="w-64 h-screen bg-gray-900 text-white flex flex-col">
      {/* Title */}
      <div className="text-2xl font-bold p-6 border-b border-gray-700">
        Hazira Port
      </div>

      {/* Navigation links */}
      <nav className="flex-grow p-4 space-y-2">
        {navItems.map((item) => (
          <Link
            key={item.name}
            to={item.path}
            className={`block px-4 py-2 rounded hover:bg-gray-700 ${
              location.pathname === item.path ? 'bg-gray-700' : ''
            }`}
          >
            {item.name}
          </Link>
        ))}
      </nav>

      {/* Logout button */}
      <div className="p-4 border-t border-gray-700">
        <button
          onClick={handleLogout}
          className="w-full bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded"
        >
          Logout
        </button>
      </div>
    </div>
  );
}
