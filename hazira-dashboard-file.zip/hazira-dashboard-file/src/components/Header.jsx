import { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';
import { useNavigate } from 'react-router-dom';

export default function Header() {
  const [userEmail, setUserEmail] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUserEmail(user?.email || '');
    };
    getUser();
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/login');
  };

  return (
    <div className="flex justify-end items-center bg-white py-2 px-4 shadow mb-4">
      <div className="relative group">
        <button className="text-sm font-medium text-gray-800">
          {userEmail || 'Account'}
        </button>
        <div className="absolute hidden group-hover:block bg-white shadow right-0 mt-2 w-48 rounded-md z-50">
          <button
            onClick={handleLogout}
            className="block w-full text-left px-4 py-2 hover:bg-gray-100"
          >
            Logout
          </button>
          <button
            onClick={() => alert('Password change coming soon')}
            className="block w-full text-left px-4 py-2 hover:bg-gray-100"
          >
            Change Password
          </button>
        </div>
      </div>
    </div>
  );
}
