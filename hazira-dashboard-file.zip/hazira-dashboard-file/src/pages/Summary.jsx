import { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';

export default function Summary() {
  const [trucks, setTrucks] = useState([]);
  const [filteredTrucks, setFilteredTrucks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchAllTrucks();
  }, []);

  const fetchAllTrucks = async () => {
    const { data, error } = await supabase
      .from('truck_entries')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error) {
      setTrucks(data);
      setFilteredTrucks(data);
    } else {
      console.error('Error fetching truck summary:', error.message);
    }

    setLoading(false);
  };

  const handleSearchChange = (e) => {
    const value = e.target.value.toLowerCase();
    setSearch(value);

    if (value === '') {
      setFilteredTrucks(trucks);
    } else {
      const filtered = trucks.filter((t) =>
        t.truck_number.toLowerCase().includes(value)
      );
      setFilteredTrucks(filtered);
    }
  };

  const calculateDuration = (inTime, outTime) => {
    const entry = new Date(inTime);
    const exit = outTime ? new Date(outTime) : new Date();
    const hours = Math.abs(exit - entry) / 36e5;
    return `${hours.toFixed(2)} hrs`;
  };

  const handleManualExit = async (truck) => {
    const now = new Date();
    const entryTime = new Date(truck.created_at);
    const hoursParked = Math.abs(now - entryTime) / 36e5;

    let violation = null;
    if (hoursParked > 3) {
      violation = 'Overstaying';
    }

    const { error } = await supabase
      .from('truck_entries')
      .update({
        exited_at: now.toISOString(),
        is_active: false,
        violation_type: violation,
      })
      .eq('id', truck.id);

    if (!error) {
      setMessage(`✅ Truck ${truck.truck_number} marked exited.`);
      fetchAllTrucks();
    } else {
      console.error('Error updating truck:', error.message);
      setMessage('❌ Failed to mark exit.');
    }

    setTimeout(() => setMessage(''), 3000);
  };

  const markPriorityTag = async (truckId) => {
  const { error } = await supabase
    .from('truck_entries')
    .update({ priority_tag: true })  // ✅ only update this
    .eq('id', truckId);

  if (!error) {
    setMessage('✅ Priority tag added.');
    fetchAllTrucks(); // Refresh the summary
  } else {
    console.error('Error marking priority:', error.message);
    setMessage('❌ Failed to update priority.');
  }

  setTimeout(() => setMessage(''), 3000);
};


  const downloadCSV = () => {
    const header = [
      'Truck Number',
      'Company',
      'Type',
      'Slot',
      'Entry Time',
      'Exit Time',
      'Duration (hrs)',
      'Violation',
      'Priority Tag'
    ];

    const rows = filteredTrucks.map((truck) => [
      truck.truck_number,
      truck.company_name,
      truck.truck_type,
      truck.slot,
      new Date(truck.created_at).toLocaleString(),
      truck.exited_at ? new Date(truck.exited_at).toLocaleString() : '—',
      calculateDuration(truck.created_at, truck.exited_at),
      truck.violation_type || '—',
      truck.priority_tag ? '✅' : '—'
    ]);

    const csvContent = [header, ...rows].map((e) => e.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'truck_summary.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 md:p-10">
      <h1 className="text-2xl font-bold mb-6">Truck Summary</h1>

      {/* Search & Download */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
        <input
          type="text"
          placeholder="Search by Truck Number..."
          value={search}
          onChange={handleSearchChange}
          className="w-full md:w-1/3 px-4 py-2 border border-gray-300 rounded-md"
        />
        <button
          onClick={downloadCSV}
          className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition"
        >
          ⬇️ Download Summary
        </button>
      </div>

      {message && (
        <div className="mb-4 bg-yellow-100 border border-yellow-300 text-yellow-800 px-4 py-2 rounded-md">
          {message}
        </div>
      )}

      {loading ? (
        <p>Loading...</p>
      ) : filteredTrucks.length === 0 ? (
        <p className="text-gray-500">No trucks match the search term.</p>
      ) : (
        <div className="overflow-x-auto border rounded-lg shadow">
          <table className="w-full text-sm">
            <thead className="bg-gray-100 text-gray-700">
              <tr>
                <th className="px-4 py-2">Truck Number</th>
                <th className="px-4 py-2">Company</th>
                <th className="px-4 py-2">Type</th>
                <th className="px-4 py-2">Slot</th>
                <th className="px-4 py-2">Entry Time</th>
                <th className="px-4 py-2">Exit Time</th>
                <th className="px-4 py-2">Duration</th>
                <th className="px-4 py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredTrucks.map((truck) => {
                const isExited = truck.exited_at !== null;

                return (
                  <tr key={truck.id} className="border-t">
                    <td className="px-4 py-2">{truck.truck_number}</td>
                    <td className="px-4 py-2">{truck.company_name}</td>
                    <td className="px-4 py-2">{truck.truck_type}</td>
                    <td className="px-4 py-2">{truck.slot}</td>
                    <td className="px-4 py-2">{new Date(truck.created_at).toLocaleString()}</td>
                    <td className="px-4 py-2">
                      {isExited ? new Date(truck.exited_at).toLocaleString() : '—'}
                    </td>
                    <td className="px-4 py-2">
                      {calculateDuration(truck.created_at, truck.exited_at)}
                    </td>
                    <td className="px-4 py-2 space-x-2">
                      {!isExited ? (
                        <button
                          onClick={() => handleManualExit(truck)}
                          className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
                        >
                          Mark Exit
                        </button>
                      ) : (
                        <button
                          onClick={() => markPriorityTag(truck.id)}
                          className="bg-yellow-400 text-white px-3 py-1 rounded hover:bg-yellow-500"
                        >
                          Mark Priority
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
