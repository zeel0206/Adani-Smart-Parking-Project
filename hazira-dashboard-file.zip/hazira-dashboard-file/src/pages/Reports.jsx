import { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';

export default function Reports() {
  const [violations, setViolations] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const perPage = 10;

  useEffect(() => {
    fetchViolations();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [search, typeFilter, fromDate, toDate, violations]);

  const fetchViolations = async () => {
    const { data, error } = await supabase
      .from('truck_entries')
      .select('*')
      .not('violation_type', 'is', null)
      .order('exited_at', { ascending: false });

    if (!error) {
      setViolations(data);
      setFiltered(data);
    }
    setLoading(false);
  };

  const applyFilters = () => {
    let filteredList = [...violations];

    if (search) {
      filteredList = filteredList.filter(v =>
        v.truck_number.toLowerCase().includes(search.toLowerCase())
      );
    }

    if (typeFilter) {
      filteredList = filteredList.filter(v => v.violation_type === typeFilter);
    }

    if (fromDate) {
      filteredList = filteredList.filter(v =>
        new Date(v.exited_at) >= new Date(fromDate)
      );
    }

    if (toDate) {
      filteredList = filteredList.filter(v =>
        new Date(v.exited_at) <= new Date(toDate)
      );
    }

    setFiltered(filteredList);
    setCurrentPage(1);
  };

  const downloadCSV = () => {
    const csvRows = [
      ['Truck Number', 'Entry Time', 'Exit Time', 'Duration (hrs)', 'Violation Type', 'Fine (₹)'],
      ...filtered.map((entry) => {
        const inTime = new Date(entry.created_at);
        const outTime = new Date(entry.exited_at);
        const duration = ((outTime - inTime) / 36e5).toFixed(2);
        const fine = entry.violation_type === 'Overstaying' ? Math.ceil(duration - 3) * 50 : 100;

        return [
          entry.truck_number,
          inTime.toLocaleString(),
          outTime.toLocaleString(),
          duration,
          entry.violation_type,
          `₹${fine}`
        ];
      }),
    ];

    const blob = new Blob([csvRows.map(row => row.join(',')).join('\n')], {
      type: 'text/csv;charset=utf-8;',
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'violation_report.csv';
    link.click();
    URL.revokeObjectURL(url);
  };

  // Summary stats
  const overstayingCount = filtered.filter(v => v.violation_type === 'Overstaying').length;
  const reentryCount = filtered.filter(v => v.violation_type === 'Unauthorized Re-entry').length;

  // Pagination logic
  const indexOfLast = currentPage * perPage;
  const indexOfFirst = indexOfLast - perPage;
  const currentRecords = filtered.slice(indexOfFirst, indexOfLast);
  const totalPages = Math.ceil(filtered.length / perPage);

  return (
    <div className="p-6 md:p-10">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-semibold">Violation Report</h1>
        <button
          onClick={downloadCSV}
          className="mt-4 md:mt-0 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          ⬇ Download CSV
        </button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <input
          type="text"
          placeholder="Search by Truck Number..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-md"
        />

        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-md"
        >
          <option value="">All Violations</option>
          <option value="Overstaying">Overstaying</option>
          <option value="Unauthorized Re-entry">Unauthorized Re-entry</option>
        </select>

        <input
          type="date"
          value={fromDate}
          onChange={(e) => setFromDate(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-md"
        />
        <input
          type="date"
          value={toDate}
          onChange={(e) => setToDate(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-md"
        />
      </div>

      {/* Summary */}
      <div className="mb-4 text-sm text-gray-600">
        Showing <strong>{filtered.length}</strong> violations — 
        Overstaying: <strong>{overstayingCount}</strong> | 
        Unauthorized Re-entry: <strong>{reentryCount}</strong>
      </div>

      {loading ? (
        <p>Loading...</p>
      ) : currentRecords.length === 0 ? (
        <p className="text-gray-500">No violations match your filter.</p>
      ) : (
        <div className="overflow-x-auto bg-white p-6 rounded-lg shadow">
          <table className="w-full text-sm">
            <thead className="bg-gray-100 text-gray-700">
              <tr>
                <th className="px-4 py-2">Truck Number</th>
                <th className="px-4 py-2">Entry Time</th>
                <th className="px-4 py-2">Exit Time</th>
                <th className="px-4 py-2">Duration (hrs)</th>
                <th className="px-4 py-2">Violation</th>
                <th className="px-4 py-2">Fine</th>
                <th className="px-4 py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {currentRecords.map((entry) => {
                const inTime = new Date(entry.created_at);
                const outTime = new Date(entry.exited_at);
                const duration = ((outTime - inTime) / 36e5).toFixed(2);
                const fine = entry.violation_type === 'Overstaying' ? Math.ceil(duration - 3) * 50 : 100;

                return (
                  <tr key={entry.id} className="border-t">
                    <td className="px-4 py-2">{entry.truck_number}</td>
                    <td className="px-4 py-2">{inTime.toLocaleString()}</td>
                    <td className="px-4 py-2">{outTime.toLocaleString()}</td>
                    <td className="px-4 py-2">{duration}</td>
                    <td className="px-4 py-2 text-red-600 font-semibold">{entry.violation_type}</td>
                    <td className={`px-4 py-2 font-bold ${fine >= 200 ? 'text-red-600' : ''}`}>
                      ₹{fine}
                    </td>
                    <td className="px-4 py-2 text-yellow-700 font-semibold">Pending</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-4 flex justify-center space-x-2">
          {Array.from({ length: totalPages }, (_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentPage(idx + 1)}
              className={`px-3 py-1 rounded ${
                currentPage === idx + 1
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700'
              }`}
            >
              {idx + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
