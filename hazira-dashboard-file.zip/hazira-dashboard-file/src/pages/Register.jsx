// src/pages/Register.jsx
import { useState } from 'react';
import { supabase } from '../supabaseClient';

export default function Register() {
  const [form, setForm] = useState({
    truckNumber: '',
    companyName: '',
    purpose: '',
    slot: '',
    truckType: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [reentryPrompt, setReentryPrompt] = useState(false);
  const [allowReentry, setAllowReentry] = useState(false);
  const [existingTruckId, setExistingTruckId] = useState(null);
  const [hasPriorityTag, setHasPriorityTag] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const checkDuplicateEntry = async (truckNumber) => {
    const { data, error } = await supabase
      .from('truck_entries')
      .select('*')
      .eq('truck_number', truckNumber)
      .eq('is_active', true);

    if (error) {
      console.error('Error checking duplicate entry:', error.message);
      return null;
    }

    return data.length > 0 ? data[0] : null;
  };

  // ✅ Alert logic (extend this later to call webhook/email service)
  const triggerAdminAlert = async (truck) => {
    console.warn(
      `[ALERT] 🚨 Unauthorized re-entry attempt:\nTruck: ${truck.truck_number}\nTime: ${new Date().toLocaleString()}`
    );

    // Example: Replace this with a webhook/email function later
    // await fetch('https://your-notification-endpoint.com/alert', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({
    //     truck_number: truck.truck_number,
    //     time: new Date().toISOString(),
    //     type: 'Re-entry without priority tag',
    //   }),
    // });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    setSubmitted(false);

    const { truckNumber, companyName, purpose, slot, truckType } = form;

    if (!truckNumber || !companyName || !purpose || !slot || !truckType) {
      setErrorMsg('All fields are required.');
      return;
    }

    const existingTruck = await checkDuplicateEntry(truckNumber);

    if (existingTruck && !allowReentry) {
      setExistingTruckId(existingTruck.id);
      setHasPriorityTag(existingTruck.priority_tag);
      setReentryPrompt(true);
      return;
    }

    if (existingTruck && allowReentry && !existingTruck.priority_tag) {
      setErrorMsg('Truck is trying to re-enter without priority tag.');

      // ✅ Trigger admin alert here
      await triggerAdminAlert(existingTruck);

      return;
    }

    // Insert new truck entry
    const { error: insertError } = await supabase.from('truck_entries').insert([
      {
        truck_number: truckNumber,
        company_name: companyName,
        purpose,
        slot,
        truck_type: truckType,
        is_active: true,
      },
    ]);

    if (insertError) {
      console.error('Supabase insert error:', insertError.message);
      setErrorMsg(insertError.message);
      return;
    }

    // ✅ Reset priority tag on previous entry if applicable
    if (existingTruck?.id) {
      await supabase
        .from('truck_entries')
        .update({ priority_tag: false })
        .eq('id', existingTruck.id);
    }

    setForm({ truckNumber: '', companyName: '', purpose: '', slot: '', truckType: '' });
    setAllowReentry(false);
    setReentryPrompt(false);
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const confirmReentry = () => {
    setAllowReentry(true);
    setReentryPrompt(false);
    setErrorMsg('');
  };

  return (
    <div className="p-6 md:p-10">
      <h1 className="text-2xl font-bold mb-4">Truck Entry</h1>

      {submitted && (
        <div className="mb-4 bg-green-100 border border-green-300 text-green-700 px-4 py-2 rounded-md">
          ✅ Truck registered successfully!
        </div>
      )}

      {errorMsg && (
        <div className="mb-4 bg-red-100 border border-red-300 text-red-700 px-4 py-2 rounded-md">
          ❌ {errorMsg}
        </div>
      )}

      {reentryPrompt && (
        <div className="mb-4 bg-yellow-100 border border-yellow-300 text-yellow-800 px-4 py-2 rounded-md">
          ⚠️ Truck is trying to re-enter.
          <br />
          {hasPriorityTag ? (
            <>
              <p className="mt-2 text-green-700 font-medium">✅ Priority Tag Detected.</p>
              <button
                onClick={confirmReentry}
                className="mt-2 inline-block bg-blue-600 text-white px-4 py-1 rounded hover:bg-blue-700"
              >
                Allow Re-entry
              </button>
            </>
          ) : (
            <p className="mt-2 font-semibold text-red-600">
              ❌ No Priority Tag Assigned. Access Denied. Admin has been notified.
            </p>
          )}
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        className="bg-white p-6 rounded-lg shadow-md space-y-5 max-w-3xl"
      >
        {/* Truck Number */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Truck Number</label>
          <input
            type="text"
            name="truckNumber"
            value={form.truckNumber}
            onChange={handleChange}
            className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2"
            required
          />
        </div>

        {/* Company Name */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Company Name</label>
          <input
            type="text"
            name="companyName"
            value={form.companyName}
            onChange={handleChange}
            className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2"
            required
          />
        </div>

        {/* Purpose & Slot */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Purpose</label>
            <select
              name="purpose"
              value={form.purpose}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2"
              required
            >
              <option value="">-- Select Purpose --</option>
              <option value="Delivery">Delivery</option>
              <option value="Pickup">Pickup</option>
              <option value="Maintenance">Maintenance</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Select Parking</label>
            <select
              name="Parking Number"
              value={form.slot}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2"
              required
            >
              <option value="">-- Choose a slot --</option>
              <option value="Slot 1">Parking 1</option>
              <option value="Slot 2">Parking 2</option>
            </select>
          </div>
        </div>

        {/* Truck Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Truck Type</label>
          <select
            name="truckType"
            value={form.truckType}
            onChange={handleChange}
            className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2"
            required
          >
            <option value="">-- Select Truck Type --</option>
            <option value="Container">Container</option>
            <option value="Cargo">Cargo</option>
            <option value="Liquid Tanker">Liquid Tanker</option>
          </select>
        </div>

        {/* Submit */}
        <div>
          <button
            type="submit"
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition"
          >
            Register Truck
          </button>
        </div>
      </form>
    </div>
  );
}
