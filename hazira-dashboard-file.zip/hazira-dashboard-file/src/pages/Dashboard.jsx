import { useEffect, useState } from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { supabase } from '../supabaseClient';

const COLORS = ['#60a5fa', '#34d399', '#f97316', '#d1d5db']; // Container, Cargo, Liquid, Empty
const TOTAL_SLOTS = 50; // Adjust if needed

export default function Dashboard() {
  const [truckStats, setTruckStats] = useState({
    total: 0,
    violations: 0,
    fines: 0,
    freeSlots: 0,
  });
  const [pieData, setPieData] = useState([]);
  const [activeTrucks, setActiveTrucks] = useState([]);
  const [topViolators, setTopViolators] = useState([]);

  const fetchDashboardData = async () => {
    // Fetch active trucks
    const { data: active, error: activeErr } = await supabase
      .from('truck_entries')
      .select('*')
      .eq('is_active', true);

    if (activeErr) {
      console.error('Error fetching active trucks:', activeErr.message);
      return;
    }

    const counts = {
      Container: 0,
      Cargo: 0,
      'Liquid Tanker': 0,
    };

    active.forEach((entry) => {
      if (counts[entry.truck_type] !== undefined) {
        counts[entry.truck_type]++;
      }
    });

    const occupied = counts.Container + counts.Cargo + counts['Liquid Tanker'];
    const free = TOTAL_SLOTS - occupied;

    setTruckStats((prev) => ({
      ...prev,
      total: occupied,
      freeSlots: free < 0 ? 0 : free,
    }));

    setPieData([
      { name: 'Container', value: counts.Container },
      { name: 'Cargo', value: counts.Cargo },
      { name: 'Liquid Tanker', value: counts['Liquid Tanker'] },
      { name: 'Empty Slots', value: free < 0 ? 0 : free },
    ]);

    setActiveTrucks(active);

    // Fetch top violators
    const { data: violationData, error: violationErr } = await supabase
      .from('truck_entries')
      .select('truck_number, created_at, exited_at, violation_type')
      .not('violation_type', 'is', null);

    if (violationErr) {
      console.error('Error fetching violations:', violationErr.message);
      return;
    }

    const violationMap = {};
    violationData.forEach((v) => {
      const truck = v.truck_number;
      const inTime = new Date(v.created_at);
      const outTime = new Date(v.exited_at);
      const duration = ((outTime - inTime) / 36e5);
      const fine = v.violation_type === 'Overstaying'
        ? Math.ceil(duration - 3) * 50
        : 100;

      if (!violationMap[truck]) {
        violationMap[truck] = {
          count: 0,
          totalFine: 0,
          lastViolation: v.exited_at,
        };
      }

      violationMap[truck].count++;
      violationMap[truck].totalFine += fine > 0 ? fine : 0;
      if (new Date(v.exited_at) > new Date(violationMap[truck].lastViolation)) {
        violationMap[truck].lastViolation = v.exited_at;
      }
    });

    const top = Object.entries(violationMap)
      .map(([truck, val]) => ({
        truck_number: truck,
        count: val.count,
        totalFine: val.totalFine,
        lastViolation: val.lastViolation,
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    setTopViolators(top);

    // Total stats
    const totalFine = violationData.reduce((acc, v) => {
      const inTime = new Date(v.created_at);
      const outTime = new Date(v.exited_at);
      const duration = ((outTime - inTime) / 36e5);
      const fine = v.violation_type === 'Overstaying'
        ? Math.ceil(duration - 3) * 50
        : 100;
      return acc + (fine > 0 ? fine : 0);
    }, 0);

    setTruckStats((prev) => ({
      ...prev,
      violations: violationData.length,
      fines: totalFine,
    }));
  };

  useEffect(() => {
    fetchDashboardData();
    const interval = setInterval(() => {
      fetchDashboardData();
    }, 30000); // Refresh every 30 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-6 md:p-10">
      <h1 className="text-2xl font-semibold mb-6">Dashboard</h1>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-green-100 p-4 rounded-lg shadow text-center">
          <p className="text-gray-600">Parked Trucks</p>
          <p className="text-2xl font-bold">{truckStats.total}</p>
        </div>
        <div className="bg-red-100 p-4 rounded-lg shadow text-center">
          <p className="text-gray-600">Violations</p>
          <p className="text-2xl font-bold">{truckStats.violations}</p>
        </div>
        <div className="bg-blue-100 p-4 rounded-lg shadow text-center">
          <p className="text-gray-600">Fines</p>
          <p className="text-2xl font-bold">₹{truckStats.fines}</p>
        </div>
        <div className="bg-gray-100 p-4 rounded-lg shadow text-center">
          <p className="text-gray-600">Free Slots</p>
          <p className="text-2xl font-bold">{truckStats.freeSlots}</p>
        </div>
      </div>

      {/* Pie Chart */}
      <div className="bg-white p-6 rounded-lg shadow mb-6">
        <h2 className="text-lg font-semibold mb-4">Slot Occupancy by Truck Type</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={100}
                label
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend verticalAlign="bottom" height={36} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Active Trucks Table */}
      <div className="bg-white p-6 rounded-lg shadow mb-6">
        <h2 className="text-lg font-semibold mb-4">Parked Trucks in Parking</h2>
        {activeTrucks.length === 0 ? (
          <p>No active trucks currently in the parking.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 text-gray-700">
                <tr>
                  <th className="px-4 py-2">Truck No.</th>
                  <th className="px-4 py-2">Type</th>
                  <th className="px-4 py-2">Slot</th>
                  <th className="px-4 py-2">Time In</th>
                </tr>
              </thead>
              <tbody>
                {activeTrucks.map((truck) => (
                  <tr key={truck.id} className="border-t">
                    <td className="px-4 py-2">{truck.truck_number}</td>
                    <td className="px-4 py-2">{truck.truck_type}</td>
                    <td className="px-4 py-2">{truck.slot}</td>
                    <td className="px-4 py-2">
                      {new Date(truck.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Top Violators Table */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-lg font-semibold mb-4 text-red-600">Top 10 Trucks with Most Violations</h2>
        {topViolators.length === 0 ? (
          <p>No violations found.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 text-gray-700">
                <tr>
                  <th className="px-4 py-2">Truck No.</th>
                  <th className="px-4 py-2">Violations</th>
                  <th className="px-4 py-2">Total Fine</th>
                  <th className="px-4 py-2">Last Violation</th>
                </tr>
              </thead>
              <tbody>
                {topViolators.map((truck) => (
                  <tr key={truck.truck_number} className="border-t">
                    <td className="px-4 py-2 font-semibold">{truck.truck_number}</td>
                    <td className="px-4 py-2">{truck.count}</td>
                    <td className="px-4 py-2 text-red-600 font-semibold">₹{truck.totalFine}</td>
                    <td className="px-4 py-2">{new Date(truck.lastViolation).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
