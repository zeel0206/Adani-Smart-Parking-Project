import { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';

const TRUCK_TYPES = ['Container', 'Dry Cargo', 'Liquid Tanker'];
const TIME_RANGES = ['3-6', '6-9', '9+'];

export default function Rates() {
  const [rates, setRates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchRates();
  }, []);

  const fetchRates = async () => {
    const { data, error } = await supabase
      .from('violation_rates')
      .select('*');

    if (!error) setRates(data);
    else console.error('Error fetching rates:', error.message);

    setLoading(false);
  };

  const handleUpdate = async (truckType, hourRange, charge) => {
    const existing = rates.find(
      (r) => r.truck_type === truckType && r.hour_range === hourRange
    );

    if (existing) {
      const { error } = await supabase
        .from('violation_rates')
        .update({ charge })
        .eq('id', existing.id);

      if (!error) {
        setMessage('✅ Rate updated successfully');
        fetchRates();
      } else {
        console.error(error.message);
      }
    }
  };

  const getCharge = (truckType, hourRange) => {
    const entry = rates.find(
      (r) => r.truck_type === truckType && r.hour_range === hourRange
    );
    return entry?.charge ?? '';
  };

  return (
    <div className="p-6 md:p-10">
      <h1 className="text-2xl font-bold mb-6">Violation Rate Module</h1>

      {message && (
        <div className="mb-4 text-green-700 bg-green-100 p-3 rounded">{message}</div>
      )}

      {loading ? (
        <p>Loading rates...</p>
      ) : (
        TRUCK_TYPES.map((type) => (
          <div key={type} className="mb-6">
            <h2 className="text-xl font-semibold mb-2">{type}</h2>
            <table className="w-full border mb-4 text-sm">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-2 border">Time Range</th>
                  <th className="p-2 border">Charge (₹)</th>
                  <th className="p-2 border">Action</th>
                </tr>
              </thead>
              <tbody>
                {TIME_RANGES.map((range) => (
                  <tr key={range}>
                    <td className="p-2 border">{range} hrs</td>
                    <td className="p-2 border">
                      <input
                        type="number"
                        defaultValue={getCharge(type, range)}
                        className="w-24 px-2 py-1 border rounded"
                        onBlur={(e) =>
                          handleUpdate(type, range, parseInt(e.target.value))
                        }
                      />
                    </td>
                    <td className="p-2 border text-center">
                      <button
                        onClick={() =>
                          handleUpdate(type, range, getCharge(type, range))
                        }
                        className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
                      >
                        Update
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))
      )}
    </div>
  );
}
