import { Navigate } from 'react-router-dom';
import { useAuth } from './AuthContext';

export default function ProtectedRoute({ children, roleRequired }) {
  const { user, role } = useAuth();

  if (!user) return <Navigate to="/login" />;
  if (roleRequired && role !== roleRequired) return <Navigate to="/unauthorized" />;

  return children;
}
