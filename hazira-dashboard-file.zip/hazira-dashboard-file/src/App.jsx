import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { supabase } from './supabaseClient';

import Sidebar from './components/Sidebar';
import Header from './components/Header';

import Dashboard from './pages/Dashboard';
import Register from './pages/Register';
import Summary from './pages/Summary';
import Rates from './pages/Rates';
import Reports from './pages/Reports';
import FastagSimulator from './components/FastagSimulator';
import Login from './pages/Login';
import Signup from './pages/Signup';

function App() {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user);
        fetchRole(session.user.id);
      } else {
        setUser(null);
        setLoading(false);
      }
    };
    checkSession();

    supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setUser(session.user);
        fetchRole(session.user.id);
      } else {
        setUser(null);
        setRole('');
      }
    });
  }, []);

  const fetchRole = async (userId) => {
    const { data, error } = await supabase
      .from('user_roles')
      .select('role')
      .eq('id', userId)
      .single();

    if (!error && data) {
      setRole(data.role);
    }
    setLoading(false);
  };

  if (loading) return <p className="p-10">Loading...</p>;

  if (!user) {
    return (
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="*" element={<Navigate to="/login" />} />
        </Routes>
      </Router>
    );
  }

  return (
    <Router>
      <div className="flex h-screen">
        <Sidebar />
        <main className="flex-1 bg-gray-100 overflow-auto">
          <Header />
          <Routes>
            <Route path="/" element={<Dashboard />} />
            {role === 'admin' && (
              <>
                <Route path="/register" element={<Register />} />
                <Route path="/summary" element={<Summary />} />
                <Route path="/rates" element={<Rates />} />
                <Route path="/reports" element={<Reports />} />
                <Route path="/fastag" element={<FastagSimulator />} />
              </>
            )}
            {role === 'security' && (
              <>
                <Route path="/summary" element={<Summary />} />
              </>
            )}
            {/* fallback */}
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
