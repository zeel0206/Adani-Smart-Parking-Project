import requests
import time
from datetime import datetime, timedelta
import subprocess

SUPABASE_FUNCTION_URL = "https://bdcxfoekzgyxykqeeojl.supabase.co "
SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJkY3hmb2Vremd5eHlrcWVlb2psIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAzMTM2MDIsImV4cCI6MjA2NTg4OTYwMn0.fT2pmPwm6DQ7bOfGfvktbVG1_ZurbIeu85B6hlKdBsY"  

scanned_tags = {}

def is_recently_processed(epc):
    now = datetime.now()
    if epc in scanned_tags and now - scanned_tags[epc] < timedelta(minutes=5):
        return True
    scanned_tags[epc] = now
    return False

def post_to_supabase(epc):
    if is_recently_processed(epc):
        print(f"⚠️ Tag {epc} recently processed. Skipping...")
        return

    print(f"📨 Sending EPC {epc} to Supabase...")
    try:
        res = requests.post(
            SUPABASE_FUNCTION_URL,
            json={"rfid": epc},  # ✅ Use 'rfid' not 'epc'
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {SUPABASE_API_KEY}"  # Optional if Edge Function doesn't require JWT
            },
            timeout=10
        )
        if res.status_code == 200:
            print("✅ Supabase responded:", res.json())
        else:
            print("❌ Error from Supabase:", res.text)
    except Exception as e:
        print("💥 Request failed:", str(e))

def parse_inventory_line(line):
    if 'epc=' in line:
        start = line.find('epc=') + 4
        end = line.find(' ', start)
        if end == -1:
            end = len(line)
        return line[start:end]
    return None

print("📡 Waiting for RFID scans... (Press Ctrl+C to stop)")

try:
    process = subprocess.Popen(
        ["python", "-m", "sllurp", "inventory", "192.168.1.10:5084", "--antennas", "1", "--tx-power", "200"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )
   
    for line in process.stdout:
        line = line.strip()
        if not line:
            continue
        print("📶 RAW:", line)  # Debug: Show every line from reader
        epc = parse_inventory_line(line)
        if epc:
             post_to_supabase(epc)


except KeyboardInterrupt:
    print("🛑 RFID scan stopped by user.")
