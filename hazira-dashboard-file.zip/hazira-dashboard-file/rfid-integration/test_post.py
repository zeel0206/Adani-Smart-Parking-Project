import requests

SUPABASE_FUNCTION_URL = "https://bdcxfoekzgyxykqeeojl.functions.supabase.co/fastag-entry"
SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJkY3hmb2Vremd5eHlrcWVlb2psIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAzMTM2MDIsImV4cCI6MjA2NTg4OTYwMn0.fT2pmPwm6DQ7bOfGfvktbVG1_ZurbIeu85B6hlKdBsY"  # 🔑 Replace with your actual anon/public key

res = requests.post(
    SUPABASE_FUNCTION_URL,
    json={"epc": "test-tag-123"},
    headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {SUPABASE_API_KEY}"
    }
)

print(res.status_code)
print(res.json())
